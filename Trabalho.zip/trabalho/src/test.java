import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class test {


public static void main(String[] args) {
        ArrayList<Amigo> listaAmigos = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
        try {
            System.out.println("Digite o nome completo do amigo:");
          String nomeCompleto = scanner.nextLine();

         System.out.println("Digite o gênero do amigo:");
         String genero = scanner.nextLine();

          System.out.println("Digite a idade do amigo:");
          int idade = scanner.nextInt();
          scanner.nextLine();

         System.out.println("Digite o email do amigo:");
         String email = scanner.nextLine();

            System.out.println("Digite a escolaridade do amigo:");
            String escolaridade = scanner.nextLine();

            System.out.println("Digite o endereço do amigo:");
            String endereco = scanner.nextLine();

            System.out.println("Digite o número do amigo:");
            String numero = scanner.nextLine();

         System.out.println("Digite o complemento do endereço do amigo:");
          String complemento = scanner.nextLine();

          System.out.println("Digite o bairro do amigo:");
         String bairro = scanner.nextLine();

         System.out.println("Digite a cidade do amigo:");
         String cidade = scanner.nextLine();

         System.out.println("Digite o estado do amigo:");
         String estado = scanner.nextLine();

         System.out.println("Digite o CEP do amigo:");
         String cep = scanner.nextLine();

         Amigo amigo = new Amigo(nomeCompleto, genero, idade, email, escolaridade, endereco,
         numero, complemento, bairro, cidade, estado, cep);

         listaAmigos.add(amigo);

         System.out.println("Amigo adicionado com sucesso!");

         System.out.println("Deseja adicionar outro amigo? (s/n)");
         String resposta = scanner.nextLine();

        if (!resposta.equalsIgnoreCase("s")) {
        break;
        }
        } catch (InputMismatchException e) {
         System.out.println("Erro: Entrada inválida. Por favor, insira os dados corretamente.");
         scanner.nextLine();
        }
        }

         System.out.println("\nLista de Amigos:");
         for (Amigo amigo : listaAmigos) {
         amigo.mostrarDados();
        }
        }
        }
