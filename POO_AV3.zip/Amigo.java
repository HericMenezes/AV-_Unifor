

public class Amigo {
    private String nomeCompleto;
    private String genero;
    private int idade;
    private String email;
    private String escolaridade;
    private String endereco;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;


    public Amigo(String nomeCompleto, String genero, int idade, String email, String escolaridade,
                 String endereco, String numero, String complemento, String bairro,
                 String cidade, String estado, String cep) {
        this.nomeCompleto = nomeCompleto;
        this.genero = genero;
        this.idade = idade;
        this.email = email;
        this.escolaridade = escolaridade;
        this.endereco = endereco;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }


    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public String getGenero() {
        return genero;
    }

    public int getIdade() {
        return idade;
    }

    public String getEmail() {
        return email;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public String getEstado() {
        return estado;
    }

    public String getCep() {
        return cep;
    }

    @Override
    public String toString(){
        return "Nome: " +nomeCompleto+ ", Gênero: " + genero + ", Idade: "+ idade +", Email: "+ email +", Escolaridade: "+ escolaridade+ ", Endereço: "+ endereco + ", Número: "+ numero+ ", Complemento: "+ complemento +", Bairro: "+ bairro +", Cidade: "+ cidade+ ", Estado: "+ estado+", CEP: "+ cep;
    }

    public void mostrarDados() {
        System.out.println("Nome Completo: " + nomeCompleto);
        System.out.println("Gênero: " + genero);
        System.out.println("Idade: " + idade);
        System.out.println("Email: " + email);
        System.out.println("Escolaridade: " + escolaridade);
        System.out.println("Endereço: " + endereco);
        System.out.println("Número: " + numero);
        System.out.println("Complemento: " + complemento);
        System.out.println("Bairro: " + bairro);
        System.out.println("Cidade: " + cidade);
        System.out.println("Estado: " + estado);
        System.out.println("CEP: " + cep);
        System.out.println();
    }
}