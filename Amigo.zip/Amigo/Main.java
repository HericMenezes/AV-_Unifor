package amigosapp;

public class Main {
    public static void main(String[] args) {
        AmigoManager amigoManager = new AmigoManager();

        // Adicionando alguns amigos para teste
        amigoManager.adicionarAmigo(new Amigo("João da Silva", "Masculino", 30, "joao@example.com", "Ensino Superior", "Rua A", "123", "Apto 1", "Centro", "Cidade A", "Estado A", "00000-000"));
        amigoManager.adicionarAmigo(new Amigo("Maria Oliveira", "Feminino", 25, "maria@example.com", "Ensino Médio", "Rua B", "456", "Casa", "Bairro B", "Cidade B", "Estado B", "11111-111"));

        // Navegação
        System.out.println("Primeiro amigo: " + amigoManager.primeiroAmigo());
        System.out.println("Próximo amigo: " + amigoManager.proximoAmigo());
        System.out.println("Amigo anterior: " + amigoManager.amigoAnterior());
        System.out.println("Último amigo: " + amigoManager.ultimoAmigo());
    }
}
