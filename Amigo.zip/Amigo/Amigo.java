package amigosapp;

public class Amigo {
    private String nomeCompleto;
    private String genero;
    private int idade;
    private String email;
    private String escolaridade;
    private String endereco;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;

    public Amigo(String nomeCompleto, String genero, int idade, String email, String escolaridade, String endereco, String numero, String complemento, String bairro, String cidade, String estado, String cep) {
        this.nomeCompleto = nomeCompleto;
        this.genero = genero;
        this.idade = idade;
        this.email = email;
        this.escolaridade = escolaridade;
        this.endereco = endereco;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }

    @Override
    public String toString() {
        return "Amigo{" +
                "nomeCompleto='" + nomeCompleto + '\'' +
                ", genero='" + genero + '\'' +
                ", idade=" + idade +
                ", email='" + email + '\'' +
                ", escolaridade='" + escolaridade + '\'' +
                ", endereco='" + endereco + '\'' +
                ", numero='" + numero + '\'' +
                ", complemento='" + complemento + '\'' +
                ", bairro='" + bairro + '\'' +
                ", cidade='" + cidade + '\'' +
                ", estado='" + estado + '\'' +
                ", cep='" + cep + '\'' +
                '}';
    }
}
