package amigosapp;

import java.util.ArrayList;
import java.util.List;

public class AmigoManager {
    private List<Amigo> amigos;
    private int currentIndex;

    public AmigoManager() {
        this.amigos = new ArrayList<>();
        this.currentIndex = -1;
    }

    public void adicionarAmigo(Amigo amigo) {
        try {
            if (amigo != null) {
                amigos.add(amigo);
                if (currentIndex == -1) currentIndex = 0;
            } else {
                throw new IllegalArgumentException("Amigo não pode ser nulo");
            }
        } catch (Exception e) {
            System.out.println("Erro ao adicionar amigo: " + e.getMessage());
        }
    }

    public Amigo primeiroAmigo() {
        if (!amigos.isEmpty()) {
            currentIndex = 0;
            return amigos.get(currentIndex);
        }
        return null;
    }

    public Amigo amigoAnterior() {
        if (currentIndex > 0) {
            currentIndex--;
            return amigos.get(currentIndex);
        }
        return null;
    }

    public Amigo proximoAmigo() {
        if (currentIndex < amigos.size() - 1) {
            currentIndex++;
            return amigos.get(currentIndex);
        }
        return null;
    }

    public Amigo ultimoAmigo() {
        if (!amigos.isEmpty()) {
            currentIndex = amigos.size() - 1;
            return amigos.get(currentIndex);
        }
        return null;
    }
}
